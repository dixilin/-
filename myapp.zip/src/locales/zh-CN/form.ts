export default {
  'form.username': '用户名',
  'form.password': '密码',
  'form.checked': '记住我',
  'form.username_tips': '请输入用户名!',
  'form.password_tips': '请输入密码!',
  'form.phone': '电话',
  'form.phone_empty_tips': '请输入电话',
  'form.phone_error_tips': '请输入正确的号码',
};
