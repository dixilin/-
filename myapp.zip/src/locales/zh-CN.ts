import form from './zh-CN/form';

export default {
  WELCOME_TO_UMI_WORLD: '{name}，欢迎光临umi的世界',
  name: '你好, {name}',
  ...form,
};
