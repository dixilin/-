import form from './ja-JP/form';

export default {
  WELCOME_TO_UMI_WORLD: '{name}, umiの世界へようこそ',
  name: 'こんにちは, {name}',
  ...form,
};
