const useDisabled = () => {
  return
}

export default useDisabled
