import form from './en-US/form';

export default {
  WELCOME_TO_UMI_WORLD: "{name}, welcome to umi's world",
  name: 'Hi, {name}',
  ...form,
};
