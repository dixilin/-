export default {
  'form.username': 'username',
  'form.password': 'password',
  'form.checked': 'remember me',
  'form.username_tips': 'Please input your username!',
  'form.password_tips': 'Please input your password!',
  'form.phone': 'phone',
  'form.phone_empty_tips': 'please input your phone',
  'form.phone_error_tips': 'please input your correct phone',
};
