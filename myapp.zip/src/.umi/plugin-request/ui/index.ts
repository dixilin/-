// @ts-nocheck
import 'antd/es/message/style';
import message from 'antd/es/message';
import 'antd/es/notification/style';
import notification from 'antd/es/notification';

export { message, notification };
