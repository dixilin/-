export default {
  'form.username': 'ユーザー名',
  'form.password': 'パスワード',
  'form.checked': '覚えてくれ',
  'form.username_tips': 'ユーザー名を入力してください!',
  'form.password_tips': 'パスワードを入力してください!',
  'form.phone': '電話番号',
  'form.phone_empty_tips': '電話番号を入力してください',
  'form.phone_error_tips': '電話番号No Right',
};
